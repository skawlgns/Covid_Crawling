import requests
import re
from bs4 import BeautifulSoup


def scrape_covid():
    print("[코로나현황]")
    url = "https://www.gbgs.go.kr/programs/corona/corona.do"
    res = requests.get(url)
    res.raise_for_status()
    soup = BeautifulSoup(res.text, "lxml")
    

    Gyeongsan_total_positive = soup.find("table", attrs={"class":"table01"}).find("tbody").find("td").get_text()
    Gyeongsan_recovery = soup.find("table", attrs={"class":"table01"}).find("tbody").find("td")

    print(Gyeongsan_total_positive) #경산 확진자
    print(Gyeongsan_recovery.next_sibling.next_sibling.next_sibling.next_sibling.get_text()) #경산 완치자

    
 

if __name__ == "__main__":

    scrape_covid()
    # 다른파일에 의해 호출될땐 실행 X